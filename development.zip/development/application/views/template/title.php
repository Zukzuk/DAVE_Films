<header id="navigation" class="">
	<a id="logo" href="#/portfolio"></a>
	<nav id="main_nav">
		<ul>
			<li class="porfolio"><a href="javascript:void(0)" onclick="app.events.dispatch('NAVIGATE', { uri:'portfolio' } ); return false;"></a></li>
			<li class="contact"><a href="javascript:void(0)" onclick="app.events.dispatch('NAVIGATE', { uri:'contact' } ); return false;"></a></li>
		</ul>
	</nav>
</header>