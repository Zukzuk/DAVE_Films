<?php
$this -> load -> view('template/header');
$this -> load -> view('template/title');
$this -> load -> view('template/login');
$this -> load -> view('template/container');
$this -> load -> view('template/footer');
?>